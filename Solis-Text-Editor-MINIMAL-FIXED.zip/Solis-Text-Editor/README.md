![screenshot](https://github.com/user-attachments/assets/eed7e9cb-d248-4973-9fa2-eb6e4886aaff)

A simple, lightweight, text editor, I'm making for myself.

Built in support for all [Catppuccin](https://catppuccin.com/) themes! 
